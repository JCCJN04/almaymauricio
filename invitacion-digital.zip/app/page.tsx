import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { InvitationTemplate } from "@/components/invitation-template"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-invitation-bg flex items-center justify-center p-6">
      <Card className="max-w-2xl w-full p-12 text-center bg-invitation-surface border-invitation-border shadow-invitation">
        <h1 className="font-serif text-5xl mb-6 text-invitation-text tracking-wide">
          Sistema de Invitaciones Digitales
        </h1>
        <p className="font-body text-lg text-invitation-muted mb-8 leading-relaxed">
          Crea invitaciones elegantes y personalizadas para tus eventos especiales. Elige entre ver la versión general o
          crear invitaciones personalizadas para cada invitado.
        </p>

        <div className="grid md:grid-cols-2 gap-6 mt-12">
          <Link href="/invitacion">
            <Button
              size="lg"
              className="w-full h-auto py-6 text-lg bg-invitation-accent hover:bg-invitation-accent-dark text-invitation-surface font-semibold tracking-wider"
            >
              Ver Invitación General
            </Button>
          </Link>

          <Link href="/personalizar">
            <Button
              size="lg"
              variant="outline"
              className="w-full h-auto py-6 text-lg border-2 border-invitation-accent text-invitation-accent hover:bg-invitation-accent hover:text-invitation-surface font-semibold tracking-wider bg-transparent"
            >
              Crear Invitaciones Personalizadas
            </Button>
          </Link>
        </div>

        <div className="mt-12 pt-8 border-t border-invitation-border">
          <p className="text-sm text-invitation-muted font-body">
            Diseño elegante • Formato digital • Listo para compartir
          </p>
        </div>
        <InvitationTemplate />
      </Card>
    </div>
  )
}
