import { InvitationTemplate } from "@/components/invitation-template"

export default async function InvitacionPersonalizadaPage({
  params,
}: {
  params: Promise<{ nombre: string }>
}) {
  const { nombre } = await params
  const nombreDecodificado = decodeURIComponent(nombre)

  return <InvitationTemplate guestName={nombreDecodificado} />
}
