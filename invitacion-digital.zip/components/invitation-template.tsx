"use client"

import { useState, useEffect, useRef } from "react"
import { Music, MicOff as MusicOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface InvitationTemplateProps {
  guestName?: string
}

export function InvitationTemplate({ guestName }: InvitationTemplateProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [countdown, setCountdown] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 })
  const audioRef = useRef<HTMLAudioElement>(null)

  // Fecha del evento - PERSONALIZAR AQUÍ
  const eventDate = new Date("2025-12-20T17:00:00-06:00")

  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date()
      const diff = eventDate.getTime() - now.getTime()

      if (diff <= 0) {
        setCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 })
        return
      }

      const totalSeconds = Math.floor(diff / 1000)
      const days = Math.floor(totalSeconds / (24 * 3600))
      const hours = Math.floor((totalSeconds % (24 * 3600)) / 3600)
      const minutes = Math.floor((totalSeconds % 3600) / 60)
      const seconds = totalSeconds % 60

      setCountdown({ days, hours, minutes, seconds })
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)

    return () => clearInterval(interval)
  }, [])

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause()
        audioRef.current.currentTime = 0
      } else {
        audioRef.current.play()
      }
      setIsPlaying(!isPlaying)
    }
  }

  return (
    <div className="min-h-screen bg-invitation-bg relative">
      {/* Texture Overlay */}
      <div
        className="fixed inset-0 opacity-40 pointer-events-none z-0"
        style={{
          backgroundImage:
            "radial-gradient(rgba(185, 147, 101, 0.18) 1px, transparent 1px), radial-gradient(rgba(185, 147, 101, 0.12) 1px, transparent 1px)",
          backgroundSize: "90px 90px",
          backgroundPosition: "0 0, 45px 45px",
        }}
      />

      {/* Music Toggle */}
      <Button
        onClick={toggleMusic}
        className={`fixed top-6 right-6 z-50 rounded-full px-6 py-3 flex items-center gap-2 ${
          isPlaying
            ? "bg-invitation-accent text-invitation-surface hover:bg-invitation-accent-dark"
            : "bg-invitation-surface/90 text-invitation-accent-dark border border-invitation-border hover:bg-invitation-surface"
        }`}
      >
        {isPlaying ? <Music className="w-5 h-5" /> : <MusicOff className="w-5 h-5" />}
        <span className="text-sm font-medium tracking-wide">{isPlaying ? "Detener música" : "Escuchar canción"}</span>
      </Button>

      <audio ref={audioRef} loop>
        <source src="/placeholder.mp3" type="audio/mpeg" />
      </audio>

      {/* Hero Section */}
      <header className="relative min-h-[85vh] flex items-center justify-center overflow-hidden border-b border-invitation-border">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img src="/elegant-wedding-couple-romantic-celebration.jpg" alt="Celebración del evento" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/55 via-black/35 to-black/70" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-6 max-w-3xl">
          {guestName && (
            <div className="mb-8 animate-fade-in">
              <p className="font-body text-invitation-surface/90 text-xl md:text-2xl mb-2">Querido/a</p>
              <h2 className="font-serif text-3xl md:text-5xl text-invitation-surface tracking-wider">{guestName}</h2>
              <div className="w-32 h-px bg-invitation-surface/60 mx-auto mt-4" />
            </div>
          )}

          <p className="font-body text-invitation-surface/85 uppercase tracking-[0.46em] text-xs md:text-sm mb-6 flex items-center justify-center gap-6">
            <span className="w-12 h-px bg-invitation-surface/60" />
            Nuestra Boda
            <span className="w-12 h-px bg-invitation-surface/60" />
          </p>

          <div className="space-y-2 mb-6">
            <h1 className="font-serif text-5xl md:text-7xl text-white uppercase tracking-[0.24em] leading-tight">
              Alma Nelly
            </h1>
            <div className="flex items-center justify-center gap-6 my-4">
              <span className="w-24 md:w-32 h-px bg-invitation-surface/55" />
              <span className="font-serif text-4xl md:text-5xl text-invitation-accent">&</span>
              <span className="w-24 md:w-32 h-px bg-invitation-surface/55" />
            </div>
            <h1 className="font-serif text-5xl md:text-7xl text-white uppercase tracking-[0.24em] leading-tight">
              Mauricio
            </h1>
          </div>

          <p className="font-body text-invitation-surface/82 text-base md:text-lg max-w-md mx-auto">
            Con gozo compartimos la dicha de nuestra unión ante Dios.
          </p>
        </div>

        {/* Countdown */}
        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10">
          <div className="flex gap-6 px-8 py-4 bg-black/40 backdrop-blur-md border border-white/30 rounded-full">
            {[
              { label: "Días", value: countdown.days },
              { label: "Horas", value: countdown.hours },
              { label: "Minutos", value: countdown.minutes },
              { label: "Segundos", value: countdown.seconds },
            ].map((item, index) => (
              <div key={item.label} className="relative flex flex-col items-center min-w-[70px]">
                {index > 0 && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-3 w-px h-12 bg-white/28" />
                )}
                <span className="font-serif text-3xl md:text-4xl text-white tracking-wider">
                  {String(item.value).padStart(2, "0")}
                </span>
                <span className="font-body text-[0.65rem] uppercase tracking-[0.32em] text-white/78 mt-1">
                  {item.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10">
        {/* Message Section */}
        <section className="py-16 px-6">
          <div className="max-w-4xl mx-auto">
            <p className="font-body text-lg md:text-xl text-invitation-muted leading-relaxed mb-8">
              Con el corazón lleno de amor y gratitud, los invitamos a ser testigos de este gran paso en nuestras vidas.
              Su presencia será una bendición y un recuerdo que atesoraremos por siempre.
            </p>

            <Card className="p-10 bg-invitation-surface border-invitation-border shadow-invitation text-center">
              <p className="font-body text-xl md:text-2xl text-invitation-muted italic mb-4">
                "Me encontré con el amor de mi vida; lo agarré y no lo solté."
              </p>
              <cite className="font-body text-sm uppercase tracking-[0.08em] text-invitation-accent-dark not-italic">
                Cantares 3:4
              </cite>
            </Card>
          </div>
        </section>

        {/* Parents Section */}
        <section className="py-16 px-6 bg-invitation-surface/70">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl md:text-4xl text-center mb-12 text-invitation-text uppercase tracking-[0.3em]">
              Con la bendición de Dios, nuestros padres
            </h2>

            <div className="grid md:grid-cols-2 gap-8">
              <Card className="p-8 bg-invitation-surface border-invitation-border shadow-invitation">
                <h3 className="font-body text-xl mb-6 text-invitation-text">Papás del Novio</h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3 font-body text-invitation-text">
                    <span className="w-7 h-7 rounded-full bg-invitation-accent/15 border border-invitation-accent/30 flex items-center justify-center text-invitation-accent-dark text-sm">
                      ✝
                    </span>
                    <span>Ricardo Parra Quiriz</span>
                  </li>
                  <li className="flex items-center gap-3 font-body text-invitation-text">
                    <span className="w-7 h-7 rounded-full bg-invitation-accent/15 border border-invitation-accent/30 flex items-center justify-center text-invitation-accent-dark text-sm">
                      ♦
                    </span>
                    <span>María Elena Hernández Molina</span>
                  </li>
                </ul>
              </Card>

              <Card className="p-8 bg-invitation-surface border-invitation-border shadow-invitation">
                <h3 className="font-body text-xl mb-6 text-invitation-text">Papás de la Novia</h3>
                <ul className="space-y-4">
                  <li className="flex items-center gap-3 font-body text-invitation-text">
                    <span className="w-7 h-7 rounded-full bg-invitation-accent/15 border border-invitation-accent/30 flex items-center justify-center text-invitation-accent-dark text-sm">
                      ✝
                    </span>
                    <span>Juan González Morales</span>
                  </li>
                  <li className="flex items-center gap-3 font-body text-invitation-text">
                    <span className="w-7 h-7 rounded-full bg-invitation-accent/15 border border-invitation-accent/30 flex items-center justify-center text-invitation-accent-dark text-sm">
                      ✝
                    </span>
                    <span>María Bertha Plata Jalomo</span>
                  </li>
                </ul>
              </Card>
            </div>
          </div>
        </section>

        {/* Bible Verse Section */}
        <section className="py-16 px-6">
          <div className="max-w-3xl mx-auto">
            <Card className="p-12 bg-gradient-to-br from-invitation-accent/18 to-invitation-surface/90 border-invitation-accent/35 shadow-invitation text-center">
              <h2 className="font-serif text-2xl md:text-3xl mb-6 text-invitation-text">Frase bíblica especial</h2>
              <p className="font-body text-xl md:text-2xl text-invitation-muted mb-6 italic">
                "Uno solo puede ser vencido, pero dos juntos pueden resistir. Y el cordón de tres hilos no se rompe
                fácilmente."
              </p>
              <p className="font-body text-sm uppercase tracking-[0.2em] text-invitation-accent-dark mb-2">
                Eclesiastés 4:12
              </p>
              <p className="font-body text-sm text-invitation-muted">
                Nuestro matrimonio se fortalece con Dios como el tercer hilo.
              </p>
            </Card>
          </div>
        </section>

        {/* Ceremony Section */}
        <section className="py-16 px-6 bg-invitation-surface/70">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif text-3xl md:text-4xl text-center mb-12 text-invitation-text uppercase tracking-[0.3em]">
              Ceremonia religiosa
            </h2>

            <Card className="p-10 bg-invitation-surface border-invitation-border shadow-invitation text-center">
              <h3 className="font-body text-2xl mb-4 text-invitation-text">Capilla San Miguel Arcángel</h3>
              <p className="font-body text-lg text-invitation-accent-dark mb-4">5:00 PM</p>
              <address className="font-body text-invitation-muted not-italic mb-8">
                C. Zuazua 314, San Miguel, Cdad. Apodaca, N.L., 66649
              </address>
              <Button
                asChild
                className="bg-invitation-accent hover:bg-invitation-accent-dark text-invitation-surface px-10 py-6 rounded-full uppercase tracking-wider font-semibold"
              >
                <a
                  href="https://www.google.com/maps/search/?api=1&query=Capilla+San+Miguel+Arc%C3%A1ngel%2C+Calle+Zuazua+314%2C+San+Miguel%2C+Apodaca%2C+NL+66649"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Ver ubicación
                </a>
              </Button>
            </Card>
          </div>
        </section>

        {/* Reception Section */}
        <section className="py-16 px-6">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-serif text-3xl md:text-4xl text-center mb-12 text-invitation-text uppercase tracking-[0.3em]">
              Recepción
            </h2>

            <Card className="p-10 bg-invitation-surface border-invitation-border shadow-invitation text-center">
              <h3 className="font-body text-2xl mb-4 text-invitation-text">Campanario Eventos</h3>
              <p className="font-body text-lg text-invitation-accent-dark mb-4">
                Seguimos celebrando después de la ceremonia
              </p>
              <address className="font-body text-invitation-muted not-italic mb-8">
                Blvd Julian Treviño Elizondo 300, El Milagro, 66634 Cdad. Apodaca, N.L., México
                <br />
                Tel. 52 81 1086 1161
              </address>
              <Button
                asChild
                className="bg-invitation-accent hover:bg-invitation-accent-dark text-invitation-surface px-10 py-6 rounded-full uppercase tracking-wider font-semibold"
              >
                <a
                  href="https://www.google.com/maps/search/?api=1&query=Campanario+Eventos%2C+Blvd+Julian+Trevi%C3%B1o+Elizondo+300%2C+El+Milagro%2C+Apodaca%2C+NL+66634"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Ver ubicación
                </a>
              </Button>
            </Card>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="py-16 px-6 bg-invitation-surface/70">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-serif text-3xl md:text-4xl text-center mb-12 text-invitation-text uppercase tracking-[0.3em]">
              Programa del gran día
            </h2>

            <Card className="p-4 bg-invitation-surface border-invitation-border shadow-invitation overflow-hidden">
              <img src="/elegant-wedding-timeline-schedule-itinerary.jpg" alt="Itinerario del evento" className="w-full h-auto rounded-lg" />
            </Card>
          </div>
        </section>

        {/* Gratitude Section */}
        <section className="py-16 px-6">
          <div className="max-w-3xl mx-auto">
            <Card className="p-12 bg-invitation-surface border-invitation-border shadow-invitation text-center">
              <p className="font-body text-xl md:text-2xl text-invitation-muted italic mb-6">
                "Que el amor que hoy celebramos se multiplique en cada uno de sus hogares. Gracias por acompañarnos."
              </p>
              <cite className="font-body text-sm uppercase tracking-[0.12em] text-invitation-accent-dark not-italic">
                Filipenses 1:3 — "Doy gracias a mi Dios cada vez que me acuerdo de ustedes."
              </cite>
            </Card>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-12 px-6 text-center border-t border-invitation-border">
        <p className="font-body text-invitation-muted mb-2">Alma Nelly & Mauricio</p>
        <p className="font-body text-invitation-muted">Con amor, esperamos celebrar contigo.</p>
      </footer>
    </div>
  )
}
